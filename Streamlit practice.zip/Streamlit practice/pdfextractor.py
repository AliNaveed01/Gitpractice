import streamlit as st
import PyPDF2

def login():
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    # press the login button
    if st.button("Login"):
        st.success("Logged in successfully!")
        st.session_state.logged_in = True
    return username, password

def extract_text_from_pdf(pdf_file):
    text = ""
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    for page_number in range(len(pdf_reader.pages)):
        page = pdf_reader.pages[page_number]
        text += page.extract_text()
    return text

def main():
    st.title("PDF Data Extractor")
    st.write("Upload a PDF file and extract its text content.")
    login()
    # erase all the content from the screen
    st.session_state.logged_in = False
    st.empty()

    uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

    st.write(uploaded_file)
    text = ""
    if uploaded_file is not None:
        text = extract_text_from_pdf(uploaded_file)
        st.subheader("Extracted Text:")
        st.write(text)

    # use the text string for further insights
    #1) extract all the dates from the text and print them 
    dates = []
    for word in text.split():
        if word.count('/') == 2:
            dates.append(word)
    st.write("Dates found in the PDF:")
    st.write(dates)
    
    #2) extract all the email addresses from the text and print them
    import re
    email_addresses = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
    st.write("Email addresses found in the PDF:")
    st.write(email_addresses)
    
    #3) extract all the phone numbers from the text and print them
    phone_numbers = re.findall(r"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", text)
    st.write("Phone numbers found in the PDF:")
    st.write(phone_numbers)
    
    #4) extract all the URLs from the text and print them
    urls = re.findall(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+", text)
    st.write("URLs found in the PDF:")
    st.write(urls)
    
    #5) find all the money mentioned in the PDF and add them
    import re
    money = re.findall(r"\$\d+\.\d+", text)
    st.write("Money mentioned in the PDF:")
    st.write(money)
    


if __name__ == "__main__":
    main()