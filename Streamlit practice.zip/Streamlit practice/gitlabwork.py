# here we will make a webapp using streamlit 
# 1: we will make a user login page
# 2: after login, we will fetch the data from csv file and will show crypto currency data using visualizations

# importing the libraries
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import plotly.figure_factory as ff
import datetime
import time
import os

#---------------------------------#
# Page layout
## Page expands to full width
st.set_page_config(page_title='Crypto-Currency Data', layout='wide')

#---------------------------------#
# Title
st.title('Crypto-Currency Data')
# we will provide a short description of the webapp
st.markdown('This webapp is a dashboard for crypto-currency data (Bitcoin, Etherium and Cardano). It is a multi-page webapp built using Streamlit')

# now we will make a login page on the sidebar
def login():
    st.sidebar.subheader('Login Section')
    # we will take the username and password from the user
    username = st.sidebar.text_input('Username')
    password = st.sidebar.text_input('Password', type='password')
    return username, password

# step 1 : when the user press login, create a new page and print hello message
username, password = login()
# clear the screen 
st.empty()
# we will check if the user has pressed the login button
if st.sidebar.button('Login'):
    # clear the screen and show the message
    #st.sidebar.empty()
    # render new screen
    st.sidebar.success('Hello {}'.format(username))
    st.sidebar.markdown('Please select the data from the sidebar to view the data')



#---------------------------------#
# Sidebar: Data Selection
st.sidebar.subheader('Data Selection')
# we will provide a list of the data that we have
data_list = ['Bitcoin', 'Etherium', 'Cardano']
# we will create a multiselect option to select the data
selected_data = st.sidebar.multiselect('Select Data', data_list)
    

#---------------------------------#
# Fetching the data
# we will fetch the data from the csv file
#@st.cache
def fetch_data(data):
    if 'Bitcoin' in data:
        btc = pd.read_csv('BTC-USD.csv')
    else:
        btc = None
    if 'Etherium' in data:
        eth = pd.read_csv('ETH-USD.csv')
    else:
        eth = None
    if 'Cardano' in data:
        ada = pd.read_csv('ADA-USD.csv')
    else:
        ada = None
    return btc, eth, ada

# we will fetch the data from the csv file
btc, eth, ada = fetch_data(selected_data)

#---------------------------------#
# Data
# we will show the data in the main page
st.header('Data')
# we will show the data in the main page
if 'Bitcoin' in selected_data:
    st.subheader('Bitcoin')
    st.write(btc.head())
if 'Etherium' in selected_data:
    st.subheader('Etherium')
    st.write(eth.head())
if 'Cardano' in selected_data:
    st.subheader('Cardano')
    st.write(ada.head())

#---------------------------------#
# Data Visualization
# we will show the data visualization in the main page
st.header('Data Visualization')

# 1: Line Chart
# we will show the line chart for the data
st.subheader('Line Chart')
if 'Bitcoin' in selected_data:
    fig = px.line(btc, x='Date', y='Close', title='Bitcoin Closing Price')
    st.plotly_chart(fig)
if 'Etherium' in selected_data:
    fig = px.line(eth, x='Date', y='Close', title='Etherium Closing Price')
    st.plotly_chart(fig)
if 'Cardano' in selected_data:
    fig = px.line(ada, x='Date', y='Close', title='Cardano Closing Price')
    st.plotly_chart(fig)

# 2: Bar Chart
# we will show the bar chart for the data
st.subheader('Bar Chart')
if 'Bitcoin' in selected_data:
    fig = px.bar(btc, x='Date', y='Close', title='Bitcoin Closing Price')
    st.plotly_chart(fig)
if 'Etherium' in selected_data:
    fig = px.bar(eth, x='Date', y='Close', title='Etherium Closing Price')
    st.plotly_chart(fig)
if 'Cardano' in selected_data:
    fig = px.bar(ada, x='Date', y='Close', title='Cardano Closing Price')
    st.plotly_chart(fig)
    
# 3 candlestick chart
# we will show the candlestick chart for the data
st.subheader('Candlestick Chart')
if 'Bitcoin' in selected_data:
    fig = go.Figure(data=[go.Candlestick(x=btc['Date'],
                open=btc['Open'],
                high=btc['High'],
                low=btc['Low'],
                close=btc['Close'])])
    fig.update_layout(autosize=False, width=1000, height=500)
    st.plotly_chart(fig)
if 'Etherium' in selected_data:
    fig = go.Figure(data=[go.Candlestick(x=eth['Date'],
                open=eth['Open'],
                high=eth['High'],
                low=eth['Low'],
                close=eth['Close'])])
    # increase the height of the chart
    fig.update_layout(autosize=False, width=1000, height=500)
    st.plotly_chart(fig)
if 'Cardano' in selected_data:
    fig = go.Figure(data=[go.Candlestick(x=ada['Date'],
                open=ada['Open'],
                high=ada['High'],
                low=ada['Low'],
                close=ada['Close'])])
    fig.update_layout(autosize=False, width=1000, height=500)
    st.plotly_chart(fig)


# #---------------------------------#streamlit run gitlabwork.py